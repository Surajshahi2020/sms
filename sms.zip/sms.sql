-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for sms
CREATE DATABASE IF NOT EXISTS `sms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `sms`;

-- Dumping structure for table sms.basic_info
CREATE TABLE IF NOT EXISTS `basic_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `server_name` varchar(255) NOT NULL,
  `platform` enum('Physical','Logical') NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `services` text DEFAULT NULL,
  `public_ip` varchar(45) DEFAULT NULL,
  `private_ip` varchar(45) DEFAULT NULL,
  `mac_address` varchar(17) DEFAULT NULL,
  `priority` enum('Critical','High','Medium','Low') DEFAULT NULL,
  `reference_option` varchar(200) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('Active','Inactive','Decommissioned') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `basic_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sms.basic_info: ~1 rows (approximately)
INSERT INTO `basic_info` (`id`, `user_id`, `server_name`, `platform`, `purpose`, `services`, `public_ip`, `private_ip`, `mac_address`, `priority`, `reference_option`, `remarks`, `status`, `created_at`, `updated_at`) VALUES
	(3, 3, 'hmis.nepalarmy.mil.np', 'Physical', 'HMIS Database', 'http, mysql, ssh, dhcp', '10.9.0.11, 10.10.26.4', '', '10.10.10.1014.18.', 'High', 'ref2', 'needed firewall', 'Active', '2026-03-09 09:42:35', '2026-03-11 08:59:33');

-- Dumping structure for table sms.notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `type` enum('info','success','warning','danger') DEFAULT 'info',
  `file_path` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sms.notifications: ~12 rows (approximately)
INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `file_path`, `is_read`, `created_at`) VALUES
	(46, 1, 'Ransomware', '<h2>A type of malware that encrypts files on the victim\'s system and demands payment to restore access.</h2>', 'warning', 'uploads/banners/back.jpg', 0, '2025-10-15 10:17:11'),
	(47, 1, 'Malicious', '<p>Malicious software such as viruses, worms, or trojans infects a system to steal data, damage files, or take control of the computer.</p>', 'success', 'uploads/banners/back.jpg', 0, '2025-10-15 10:17:19'),
	(51, 1, 'Phishing', '<p>Phishing is a type of social‑engineering attack where a malicious actor (the “phisher”) tries to trick people into revealing sensitive information (credentials, financial data, personal info) or into performing actions (clicking links, opening attachments) that compromise security.</p>', 'danger', 'uploads/banners/back.jpg', 0, '2025-10-16 14:44:08'),
	(52, 1, 'Man-in-the-Middle (MITM) Attack', '<p><span class="ql-size-large">An attacker intercepts communication between two parties to eavesdrop, steal data, or manipulate messages without the users’ knowledge.</span></p>', 'info', 'uploads/banners/back.jpg', 0, '2025-10-16 15:29:50'),
	(53, 1, 'SQL Injection', '<p><span class="ql-size-large">An attacker injects malicious SQL code into input fields to access, modify, or delete database information without authorization.</span></p>', 'info', 'uploads/banners/back.jpg', 0, '2025-10-16 15:30:19'),
	(54, 1, 'Cross-Site Scripting (XSS)', '<p><span class="ql-size-large">Attackers inject malicious scripts into webpages that run in users’ browsers, often stealing session cookies or redirecting users to malicious sites.</span></p>', 'info', 'uploads/banners/back.jpg', 0, '2025-10-16 15:30:51'),
	(55, 1, 'Brute Force Attack', '<p><span class="ql-size-large">An attacker systematically tries all possible passwords or keys until the correct one is found to gain unauthorized access.</span></p>', 'info', 'uploads/banners/back.jpg', 0, '2025-10-16 15:31:30'),
	(56, 1, 'Ransomware', '<h2>हामीले केही सरकारी सर्भरहरूमा Ransomware जस्ता एन्क्रिप्शन गतिविधि पत्ता लगाएका छौं। प्रभावित सर्भरहरूमा फाइलहरू एन्क्रिप्ट र पहुँच अवरुद्ध हुने जोखिम छ।</h2>', 'success', 'uploads/banners/back.jpg', 0, '2025-10-16 16:34:21'),
	(57, 1, 'नयाँ साइबर आक्रमण चेतावनी', '<p><span class="ql-size-large">हामीले विभिन्न सरकारी नेटवर्कहरूमा असामान्य गतिविधि पत्ता लगाएका छौं। यो आक्रमण Phishing, Malware, वा Ransomware हुन सक्छ।</span></p><ul><li><span class="ql-size-large">आफ्ना पासवर्डहरू तुरुन्त परिवर्तन गर्नुहोस्।</span></li><li><span class="ql-size-large">अज्ञात ईमेल वा लिंकमा क्लिक नगर्नुहोस्।</span></li><li><span class="ql-size-large">महत्वपूर्ण डेटा नियमित रूपमा ब्याकअप गर्नुहोस्।</span></li><li><span class="ql-size-large">यदि कुनै अनधिकृत गतिविधि देखियो भने IT विभागलाई तुरुन्त जानकारी दिनुहोस्।</span></li></ul><p><span class="ql-size-large">सुरक्षा सतर्कता अपनाउनुहोस् र कुनै पनि शंका भएमा तत्काल रिपोर्ट गर्नुहोस्।</span></p>', 'warning', 'uploads/banners/Weekly social sites monitoring.pptx', 0, '2025-10-16 18:45:41'),
	(59, 1, 'Id ea consequuntur', '<p>Ut nulla et velit de.</p>', 'success', 'uploads/banners/Weekly social sites monitoring.pptx', 0, '2025-10-16 20:32:20'),
	(60, 1, 'Phishing Attack', '<p>Phishing is a type of social‑engineering attack where criminals impersonate a trusted person, service, or brand to trick victims into revealing sensitive information (passwords, credit‑card numbers, authentication codes), downloading malware, or taking actions that compromise security. Phishing comes in many forms: deceptive emails, malicious links, fake websites, SMS (smishing), voice calls (vishing), and targeted spear‑phishing.Recognize phishing:Sender address looks wrong (misspelled domain, subtle subdomain tricks).Generic greeting (“Dear user”) instead of your name.Urgent or threatening language (“Immediate action required”, “Account will be closed”).Unexpected attachments or links — especially shortened links or unfamiliar domains.Links whose visible text doesn’t match the real URL (hover to preview).Requests for credentials, 2FA codes, or payments via unusual channels.Poor grammar, spelling mistakes, odd formatting or logos that look slightly off.Unsolicited requests that ask you to bypass usual procedures (e.g., pay a vendor without invoice verification). Phishing is a type of social‑engineering attack where criminals impersonate a trusted person, service, or brand to trick victims into revealing sensitive information (passwords, credit‑card numbers, authentication codes), downloading malware, or taking actions that compromise security. Phishing comes in many forms: deceptive emails, malicious links, fake websites, SMS (smishing), voice calls (vishing), and targeted spear‑phishing.Recognize phishing:Sender address looks wrong (misspelled domain, subtle subdomain tricks).Generic greeting (“Dear user”) instead of your name.Urgent or threatening language (“Immediate action required”, “Account will be closed”).Unexpected attachments or links — especially shortened links or unfamiliar domains.Links whose visible text doesn’t match the real URL (hover to preview).Requests for credentials, 2FA codes, or payments via unusual channels.Poor grammar, spelling mistakes, odd formatting or logos that look slightly off.Unsolicited requests that ask you to bypass usual procedures (e.g., pay a vendor without invoice verification).</p>', 'info', 'uploads/banners/Weekly social sites monitoring.pptx', 0, '2025-10-17 06:31:33'),
	(61, 1, 'Computer Virus', '<p>A <strong>computer virus</strong> is a type of malicious software program designed to <strong>disrupt, damage, or gain unauthorized access</strong> to computers, networks, or data. Just like a biological virus spreads from person to person, a computer virus <strong>spreads from file to file or system to system</strong>.</p>', 'info', 'uploads/banners/edited one.jpg', 0, '2025-10-18 02:43:01');

-- Dumping structure for table sms.notification_comments
CREATE TABLE IF NOT EXISTS `notification_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `notification_id` (`notification_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notification_comments_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notification_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sms.notification_comments: ~16 rows (approximately)
INSERT INTO `notification_comments` (`id`, `notification_id`, `user_id`, `comment`, `created_at`) VALUES
	(2, 57, 2, 'This is helpful', '2025-10-17 01:31:45'),
	(3, 57, 3, 'This is helpful', '2025-10-17 01:32:11'),
	(4, 57, 1, 'This is desgined so that this is helpful.', '2025-10-17 01:32:53'),
	(5, 57, 1, 'Okay', '2025-10-17 01:37:45'),
	(6, 56, 2, 'ok', '2025-10-17 02:00:17'),
	(7, 56, 2, 'oik', '2025-10-17 02:00:20'),
	(8, 56, 2, 'what is that', '2025-10-17 02:00:24'),
	(9, 55, 1, 'ok', '2025-10-17 02:30:37'),
	(10, 55, 1, 'nothinfg', '2025-10-17 02:30:40'),
	(11, 51, 1, 'ok', '2025-10-17 10:27:32'),
	(12, 59, 3, 'aaa', '2025-10-17 10:52:27'),
	(13, 59, 3, 'This is helpful', '2025-10-17 10:52:30'),
	(14, 59, 2, 'This is helpful too', '2025-10-17 10:52:49'),
	(15, 59, 2, 'no problem', '2025-10-17 10:52:58'),
	(16, 59, 2, 'corrected successfully.', '2025-10-17 12:09:13'),
	(17, 56, 3, 'asasas', '2025-10-17 12:15:03');

-- Dumping structure for table sms.notification_reads
CREATE TABLE IF NOT EXISTS `notification_reads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_at` datetime DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sms.notification_reads: ~34 rows (approximately)
INSERT INTO `notification_reads` (`id`, `notification_id`, `user_id`, `read_at`, `is_read`) VALUES
	(32, 59, 3, '2025-10-17 12:04:06', 1),
	(33, 57, 3, '2025-10-17 12:04:02', 1),
	(34, 56, 3, '2025-10-17 12:14:58', 1),
	(35, 55, 3, '2026-03-01 12:51:09', 1),
	(36, 57, 1, '2025-10-17 10:51:35', 1),
	(37, 59, 1, '2025-10-17 10:57:08', 1),
	(38, 56, 1, '2025-10-17 10:47:22', 1),
	(39, 55, 1, '2025-10-17 10:51:38', 1),
	(40, 47, 2, '2025-10-17 12:09:38', 1),
	(41, 59, 2, '2025-10-17 12:04:42', 1),
	(42, 57, 2, '2025-10-17 10:53:27', 1),
	(43, 56, 2, '2025-10-17 10:54:12', 1),
	(44, 55, 2, '2025-10-17 10:54:14', 1),
	(45, 54, 2, '2025-10-17 12:04:44', 1),
	(46, 51, 2, '2025-10-17 12:08:49', 1),
	(47, 53, 2, '2025-10-17 12:04:57', 1),
	(48, 52, 2, '2025-10-17 12:08:46', 1),
	(49, 46, 2, '2025-10-17 12:09:00', 1),
	(50, 54, 3, '2026-03-09 11:35:17', 1),
	(51, 53, 3, '2026-03-09 11:35:46', 1),
	(52, 51, 3, '2026-03-09 11:35:49', 1),
	(53, 52, 3, '2026-03-09 11:35:48', 1),
	(54, 47, 3, '2025-10-17 12:14:49', 1),
	(55, 54, 1, '2025-10-17 10:47:29', 1),
	(56, 53, 1, '2025-10-17 10:51:21', 1),
	(57, 52, 1, '2025-10-17 10:09:48', 1),
	(58, 51, 1, '2025-10-17 10:47:41', 1),
	(59, 47, 1, '2025-10-17 10:47:35', 1),
	(60, 46, 1, '2025-10-17 10:28:49', 1),
	(61, 46, 3, '2025-10-17 10:52:12', 1),
	(62, 60, 1, '2025-10-17 14:59:13', 1),
	(63, 60, 2, '2025-10-17 15:48:32', 1),
	(64, 61, 3, '2026-03-01 12:23:32', 1),
	(65, 60, 3, '2026-03-01 12:26:04', 1);

-- Dumping structure for table sms.ranks
CREATE TABLE IF NOT EXISTS `ranks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rank_code` int(11) DEFAULT NULL,
  `name_nepali` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rank_code` (`rank_code`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sms.ranks: ~48 rows (approximately)
INSERT INTO `ranks` (`id`, `rank_code`, `name_nepali`) VALUES
	(1, 3, 'महारथी'),
	(2, 5, 'रथी'),
	(3, 7, 'उपरथी'),
	(4, 9, 'सहायक रथी'),
	(5, 10, 'आ.सहायक रथी'),
	(6, 11, 'महा सेनानी'),
	(7, 12, 'आ.महा सेनानी'),
	(8, 13, 'प्रमुख सेनानी'),
	(9, 14, 'आ. प्रमुख सेनानी'),
	(10, 15, 'सेनानी'),
	(11, 16, 'आ.सेनानी'),
	(12, 17, 'सह. सेनानी'),
	(13, 18, 'आ.सह सेनानी'),
	(14, 19, 'उप सेनानी'),
	(15, 21, 'सहायक सेनानी'),
	(16, 23, 'अधिकृत क्याडेट शुरु'),
	(17, 24, 'पदिक क्याडेट'),
	(18, 25, 'पदिक कर्मचारी क्याडेट'),
	(19, 26, 'इन्सर्भिस क्याडेट'),
	(20, 27, 'मानार्थ सह सेनानी'),
	(21, 29, 'मानार्थ उप सेनानी'),
	(22, 31, 'प्रमुख सुवेदार'),
	(23, 33, 'सिनियर सुवेदार'),
	(24, 35, 'सुबेदार'),
	(25, 37, 'जमदार'),
	(26, 39, 'गण कार्य हुद्बा'),
	(27, 41, 'गण प्रबन्ध हुद्बा'),
	(28, 43, 'गुल्म कार्य हुद्बा'),
	(29, 45, 'गुल्म प्रबन्ध हुद्बा'),
	(30, 47, 'हुद्बा'),
	(31, 49, 'अमल्दार'),
	(32, 51, 'प्युठ'),
	(33, 53, 'सिपाही'),
	(34, 54, 'एन.सि.ई.  पाँचौ स्तर'),
	(35, 55, 'सैन्य'),
	(36, 56, 'ए.सैन्य'),
	(37, 58, 'एन.सि.ई. चौथो स्तर'),
	(38, 59, 'कोते'),
	(39, 60, 'एन.सि.ई. तेस्रो स्तर'),
	(40, 62, 'एन.सि.ई. दोस्रो स्तर'),
	(41, 63, 'एन.सि.ई. प्रथम स्तर'),
	(42, 77, 'हुद्बा क्याडेट'),
	(43, 100, 'वरिष्ठ चार्टर्ड एकाउन्टेन्ट'),
	(44, 101, 'प्राड सहायक रथी'),
	(45, 102, 'शाखा अधिकृत'),
	(46, 103, 'सेनानी (अ.प्रा.)'),
	(47, 104, 'प्रमुख सेनानी (अ.प्रा.)'),
	(48, 105, 'नायव सुब्बा');

-- Dumping structure for table sms.server_os_info
CREATE TABLE IF NOT EXISTS `server_os_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'References users table',
  `basic_info_id` int(11) NOT NULL COMMENT 'References basic_info table',
  `os_windows` varchar(255) DEFAULT NULL COMMENT 'Windows version details',
  `os_linux` varchar(255) DEFAULT NULL COMMENT 'Linux distribution and version',
  `os_other` varchar(255) DEFAULT NULL COMMENT 'Other OS details',
  `os_patches_status` enum('Yes','No','Partial','N/A') DEFAULT NULL,
  `os_patches_details` text DEFAULT NULL,
  `installed_databases` text DEFAULT NULL COMMENT 'List of databases installed',
  `db_admin` varchar(255) DEFAULT NULL COMMENT 'Database admin username',
  `db_updated_overall` enum('Yes','No') DEFAULT NULL,
  `db_updated_details` text DEFAULT NULL,
  `services_frameworks` text DEFAULT NULL,
  `admin_computer` varchar(255) DEFAULT NULL,
  `admin_count` int(11) DEFAULT 1,
  `admin_count_reason` text DEFAULT NULL,
  `normal_users_count` int(11) DEFAULT 0,
  `normal_users_details` text DEFAULT NULL,
  `password_policy_status` enum('Yes','No') DEFAULT NULL,
  `password_length_details` varchar(255) DEFAULT NULL,
  `password_combo_details` varchar(255) DEFAULT NULL,
  `password_policy_reason` text DEFAULT NULL,
  `password_logbook_status` enum('Yes','No','N/A') DEFAULT NULL,
  `password_logbook_details` text DEFAULT NULL,
  `server_type` varchar(100) DEFAULT NULL,
  `server_type_other` varchar(255) DEFAULT NULL,
  `certificate_used` enum('Yes','No','N/A') DEFAULT NULL,
  `certificate_details` varchar(255) DEFAULT NULL,
  `certificate_expiry` date DEFAULT NULL,
  `antivirus_installed` enum('Yes','No','N/A') DEFAULT NULL,
  `antivirus_details` varchar(255) DEFAULT NULL,
  `antivirus_updated` enum('Yes','No','Partial','N/A') DEFAULT NULL,
  `antivirus_update_details` varchar(255) DEFAULT NULL,
  `selinux_enabled` enum('Yes','No','N/A') DEFAULT NULL,
  `selinux_details` varchar(255) DEFAULT NULL,
  `remote_admin_enabled` enum('Yes','No') DEFAULT NULL,
  `remote_admin_details` text DEFAULT NULL,
  `remote_policy_followed` enum('Yes','No','Partial','N/A') DEFAULT NULL,
  `remote_policy_details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_basic_info` (`basic_info_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_server_type` (`server_type`),
  KEY `idx_os_type` (`os_windows`,`os_linux`,`os_other`),
  CONSTRAINT `fk_osinfo_basic_info` FOREIGN KEY (`basic_info_id`) REFERENCES `basic_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_osinfo_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sms.server_os_info: ~0 rows (approximately)

-- Dumping structure for table sms.units
CREATE TABLE IF NOT EXISTS `units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) DEFAULT NULL,
  `name_nepali` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_id` (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sms.units: ~144 rows (approximately)
INSERT INTO `units` (`id`, `unit_id`, `name_nepali`) VALUES
	(1, 74, 'अति विशिष्त व्यक्ति सुरक्षा निर्देशनालय'),
	(2, 27, 'अनुसन्धान र विस्तार निर्देशनालय'),
	(3, 58, 'असवाव निर्देशनालय'),
	(4, 113, 'अस्थायी निबेश'),
	(5, 106, 'आपुर्ति तथा परिवहन गण'),
	(6, 86, 'आपुर्ति तथा परिवहन निर्देशनालय'),
	(7, 115, 'आर्टिलरी तालिम शिक्षालय'),
	(8, 18, 'आवास तथा विमा शाखा, कल्याणकारी योजना निर्देशनालय'),
	(9, 49, 'ईन्जिनियरिङ्ग विभाग'),
	(10, 127, 'उत्तर पश्चिम पृतना'),
	(11, 124, 'उपत्यका पृतना'),
	(12, 91, 'एम.र्इ.एस. (के.शा.)'),
	(13, 90, 'एम्युनिशन कार्य महाशाखा'),
	(14, 68, 'कलेज अफ मेडिकल पोलिटेक्निक'),
	(15, 12, 'कल्याणकारी योजना निर्देशनालय'),
	(16, 23, 'कल्याणकारी स्वास्थ्य सेवा व्यवस्थापन महाशाखा'),
	(17, 21, 'का. मु. प्रधान सेनापतिको कार्यालय'),
	(18, 136, 'काठमाडौँ-तराई मधेश द्रुतमार्ग सडक आयोजना कार्यालय'),
	(19, 46, 'कार्यरथीको कार्यालय'),
	(20, 20, 'कोष तथा लेखा नियन्त्रक महाशाखा, कल्याणकारी योजना निर्देशनालय'),
	(21, 81, 'गणेशदल गण'),
	(22, 8, 'गुणस्तर नियन्त्रण निर्देशनालय'),
	(23, 94, 'गुणस्तर नियन्त्रण निर्देशनालय'),
	(24, 67, 'चिकित्सा शास्त्र महाविद्यालय'),
	(25, 98, 'छापाखाना शाखा, श्रब्यदृश्य माहाशाखा, सै.ज.नि.'),
	(26, 76, 'जगदल गण'),
	(27, 60, 'जंगी असवाव खाना'),
	(28, 73, 'जनसम्पर्क तथा सूचना निर्देशनालय'),
	(29, 64, 'टु.मु. कोतखाना डिपो'),
	(30, 128, 'त्रिभुवन आर्मी अफिसर्स क्लब'),
	(31, 144, 'नं. १ युद्धकवच गुल्म'),
	(32, 134, 'नं. १ र्इन्टेलिजेन्स गण'),
	(33, 78, 'नं. १३ बाहिनी अड्रडा'),
	(34, 77, 'नं. १४ बाहिनी अड्रडा'),
	(35, 72, 'नं. १५ बाहिनी अड्रडा'),
	(36, 79, 'नं. १६ बाहिनी अड्रडा'),
	(37, 71, 'नं. १७ बाहिनी अड्रडा'),
	(38, 143, 'नयाँ गोरख गण'),
	(39, 66, 'नर्सिङ्ग महाविद्यालय'),
	(40, 7, 'निरीक्षण निर्देशनालय'),
	(41, 51, 'निरीक्षण निर्देशनालय'),
	(42, 50, 'निरीक्षणाधिकृतको कार्यालय'),
	(43, 87, 'निवेश, कार्यरथी विभाग'),
	(44, 36, 'नीति तथा योजना निर्देशनालय'),
	(45, 43, 'नीति तथा योजना महाशाखा'),
	(46, 105, 'नेपाल क्याभलरी'),
	(47, 114, 'नेपाली सेना वार कलेज'),
	(48, 59, 'नेपाली सेना स्वास्थ्य विज्ञान संस्थान'),
	(49, 118, 'नेपाली सैनिक प्रतिष्ठान'),
	(50, 111, 'पशु बिकास तथा पशु चिकित्शा निर्देशनालय'),
	(51, 61, 'पश्चिम एयर बेश'),
	(52, 125, 'पश्चिम पृतना'),
	(53, 69, 'पि.एस्.ओज. कार्यालय'),
	(54, 120, 'पूर्वी पृतना'),
	(55, 9, 'प्रधान सेनापतिको कार्यालय'),
	(56, 47, 'प्रबन्धरथीको कार्यालय'),
	(57, 56, 'प्राप्ती उपशाखा, सैनिक सामग्री प्राप्ती निर्देशनालय'),
	(58, 44, 'फौज योजना महाशाखा'),
	(59, 53, 'बजेट निर्देशनालय'),
	(60, 28, 'बलाधिकृतको कार्यालय'),
	(61, 1, 'बलाध्यक्षको कार्यालय'),
	(62, 135, 'बहु व्यवसाय उद्योग पहिरन सामाग्री शाखा'),
	(63, 83, 'भर्ना छनौट निर्देशनालय'),
	(64, 109, 'भैरव बहान गुल्म'),
	(65, 126, 'मध्य पश्चिम पृतना'),
	(66, 122, 'मध्य पूर्वी पृतना'),
	(67, 123, 'मध्य पृतना'),
	(68, 99, 'मनोबैज्ञानिक कार्य महाशाखा'),
	(69, 3, 'मानव अधिकार निर्देशनालय'),
	(70, 55, 'मिन्हा मोजारा'),
	(71, 97, 'युद्ध कवच गण'),
	(72, 40, 'युद्धकार्य निर्देशनालय'),
	(73, 29, 'युद्धकार्य महानिर्देशनालय'),
	(74, 19, 'योजना तथा अनुसन्धान महाशाखा, कल्याणकारी योजना निर्देशनालय'),
	(75, 138, 'रक्षा मन्त्रालय'),
	(76, 41, 'रणनीतिक तथा दीर्घकालीन योजना निर्देशनालय'),
	(77, 75, 'राजदल गण'),
	(78, 14, 'राष्ट्रिय निकुञ्ज तथा बन्यजन्तु आरक्ष निर्देशनालय'),
	(79, 141, 'राष्ट्रिय सुरक्षा परिषदको सचिवालय'),
	(80, 62, 'राष्ट्रिय सेवा दल'),
	(81, 104, 'रेडियो तथा प्रकाशन शाखा'),
	(82, 132, 'र्इन्जिनियर तालिम शिक्षालय'),
	(83, 129, 'वन तथा पर्यावरण सुरक्षा निर्देशनालय'),
	(84, 101, 'विकास निर्माण कार्यदल गण १'),
	(85, 102, 'विकास निर्माण कार्यदल गण २'),
	(86, 54, 'विकास निर्माण निर्देशनालय'),
	(87, 65, 'विदेश उपशाखा, सैनिक सामग्री प्राप्ती निर्देशनालय'),
	(88, 38, 'विदेश तालिम शाखा, सैनिक तालिम निर्देशनालय, सै.ता. तथा ड.म‍.नि.'),
	(89, 96, 'विद्युत तथा यान्त्रिक शिक्षालय'),
	(90, 95, 'विद्युत तथा यान्त्रिक सेवा केन्द्र'),
	(91, 11, 'विद्युत तथा यान्त्रिक सेवा निर्देशनालय'),
	(92, 35, 'विपद व्यवस्थापन निर्देशनालय'),
	(93, 137, 'विशेष फौज बाहिनी'),
	(94, 25, 'वीरेन्द्र अस्पताल'),
	(95, 84, 'वेतन बृति तथा समारोह निर्देशनालय'),
	(96, 33, 'व्यवस्था, नीति तथा योजना महानिर्देशनालय'),
	(97, 34, 'शान्ति सेना संचालन निर्देशनालय'),
	(98, 110, 'शार्दुलजंग गुल्म'),
	(99, 6, 'शिकायत जाँच निर्देशनालय'),
	(100, 93, 'शिकायत जाँच निर्देशनालय'),
	(101, 17, 'शैक्षिक शाखा, कल्याणकारी योजना निर्देशनालय'),
	(102, 103, 'श्रब्यदृश्य शाखा'),
	(103, 48, 'संभाररथीको कार्यालय'),
	(104, 80, 'समन्वय शाखा, बलाधिकृतको कार्यालय'),
	(105, 10, 'समन्वय शाखा, बलाध्यक्षको कार्यालय'),
	(106, 100, 'समारोह श्रब्यदृश्य महाशाखा'),
	(107, 130, 'सर्भे महाशाखा'),
	(108, 4, 'सर्वोत्कृष्ट अभ्यास महाशाखा'),
	(109, 92, 'सर्वोत्कृष्ट अभ्यास महाशाखा'),
	(110, 2, 'सहायक बलाध्यक्षको कार्यालय'),
	(111, 142, 'साइबर सुरक्षा निर्देशनालय'),
	(112, 82, 'सिग्नल तालिम शिक्षालय'),
	(113, 121, 'सुदुर पश्चिम पृतना'),
	(114, 131, 'सुन्दरीजल आर्सनल कार्यालय'),
	(115, 140, 'सुरक्षा तथा समारोह व्यवस्था सचिवालय, उपराष्ट्रपतिको कार्यालय'),
	(116, 139, 'सुरक्षा तथा समारोह व्यवस्था सचिवालय, राष्ट्रपति भवन'),
	(117, 22, 'सूचना तथा प्रविधि महाशाखा'),
	(118, 5, 'सेना प्राड विवाक'),
	(119, 89, 'सैनिक अभिलेखालय'),
	(120, 70, 'सैनिक आर्थिक प्रशासन विभाग'),
	(121, 133, 'सैनिक आवसिय माध्यमिक बिद्यालय, भक्तपुर'),
	(122, 31, 'सैनिक इन्टेलिजेन्स महानिर्देशनालय'),
	(123, 39, 'सैनिक ईण्टेलिजेन्स बाहिनी'),
	(124, 117, 'सैनिक कमाण्ड तथा स्टाफ कलेज'),
	(125, 116, 'सैनिक केन्द्रिय पुस्तकालय'),
	(126, 63, 'सैनिक गठ्ठाघर डिपो'),
	(127, 30, 'सैनिक तालिम तथा डक्ट्रिन महानिर्देशनालय'),
	(128, 24, 'सैनिक पुनर्स्थापना केन्द्र'),
	(129, 88, 'सैनिक प्रहरी गण'),
	(130, 112, 'सैनिक बन्दोबस्ती शिक्षालय'),
	(131, 107, 'सैनिक ब्याण्ड'),
	(132, 42, 'सैनिक शारीरिक तालिम तथा खेलकुद केन्द्र'),
	(133, 52, 'सैनिक संगठन निर्देशनालय'),
	(134, 108, 'सैनिक संग्रहालय'),
	(135, 26, 'सैनिक सचिव  विभाग'),
	(136, 15, 'सैनिक सामग्री उत्पादन तथा यान्त्रिक सेवा महानिर्देशनालय'),
	(137, 16, 'सैनिक सामग्री उत्पादन निर्देशनालय'),
	(138, 13, 'सैनिक स्वास्थ्य महानिर्देशनालय'),
	(139, 32, 'सैनिक हवाई महानिर्देशनालय'),
	(140, 57, 'सैनिक हवाई महानिर्देशनालय,मर्मत तथा सम्भार'),
	(141, 85, 'स्थपति निर्देशनालय'),
	(142, 37, 'स्वदेश तालिम शाखा, सैनिक तालिम निर्देशनालय, सै.ता. तथा ड.म‍.नि.'),
	(143, 119, 'स्वास्थ्य सेवा व्यवस्थापन महाशाखा'),
	(144, 45, 'हतियार तथा उपकरण महाशाखा');

-- Dumping structure for table sms.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_no` varchar(20) NOT NULL,
  `rank_code` int(11) NOT NULL,
  `full_name_en` varchar(100) NOT NULL,
  `full_name_ne` varchar(100) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `role_as` tinyint(4) DEFAULT 0,
  `is_void` tinyint(1) DEFAULT 0,
  `is_active` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `personnel_no` (`personnel_no`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sms.users: ~9 rows (approximately)
INSERT INTO `users` (`id`, `personnel_no`, `rank_code`, `full_name_en`, `full_name_ne`, `unit_id`, `phone`, `email`, `password`, `image`, `role_as`, `is_void`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, '8512', 19, 'Suraj shahi', 'सुरज शाही', 124, '9809461773', 'superadmin@gmail.com', '$2y$10$MzYLt3tUY.prnbCkMov/Z.d4tzWSfsDa3NSaPsO41IjJr3e0t1016', 'user_20250915_195650_68c81ea614c72.jpg', 2, 0, 1, '2025-09-15 14:11:50', '2025-10-10 04:09:29'),
	(2, '8571', 19, 'Dikshya Thapa', 'दीक्षा थापा', 74, '9809461774', 'admin@gmail.com', '$2y$10$DBeFRrwSaDUvUiFdPy46e.2Vp2lg84Kz/0no1yyeqOmtx/sTw.lBy', 'user_20250915_204946_68c82b0e4c32a.jpg', 1, 0, 1, '2025-09-15 15:04:46', '2025-10-10 04:11:17'),
	(3, '8572', 19, 'Susmin Basnet', 'सुस्मिन बस्नेत', 59, '9809461773', 'user@gmail.com', '$2y$10$DNVyaLYkJPaExAu4YInLK.fid/qh1uUX4TP64CRknczQWMHsrD656', 'user_20250915_205516_68c82c58a6c1c.jpg', 0, 0, 1, '2025-09-15 15:10:16', '2025-10-10 04:12:12'),
	(10, '85154', 3, 'Suraj shahi', 'सुरज शाही', 68, '9809461773', 'adsmin@gmail.com', '$2y$10$1erByDTERwtl1PqSNa8QauNL/U2tMtWMIKkFelJZA/Fx/zHnez2ne', 'user_20251014_183542_68ee4722d3783.png', 0, 0, 0, '2025-10-14 12:50:42', '2025-10-14 12:50:42'),
	(12, '851542', 10, 'Suraj shahi', 'Hyatt Talley', 91, '9809461773', 'supddderadmin@gmail.com', '$2y$10$NXzedAovNu3sz5ULtter1u6AT5sMq0lqSgEhjsN075905mdR/Ov0W', 'user_20251014_184753_68ee49fd09234.png', 0, 0, 0, '2025-10-14 13:02:53', '2025-10-14 13:02:53'),
	(13, '21212', 103, 'Emery Mcdonald', 'Dillon Hudson', 45, '9811455254', 'pasoc@mailinator.com', '$2y$10$WyRUTx3riGH8UVM8.E3YvO1xjcqWvWargTOvEkxoZWJzsdQXhXa.m', 'user_20251014_185115_68ee4ac71c352.png', 0, 0, 0, '2025-10-14 13:06:15', '2025-10-14 13:06:15'),
	(14, '8515411', 14, 'Suraj shahi', 'सुरज शाही', 127, '9809461774', 'assdmin@gmail.com', '$2y$10$g/76pDJHFCdGJPR2eocLAu2fs40YWLCc2IGs/GEdK5q2dkVnMPyR6', 'user_20251014_185411_68ee4b7749648.png', 0, 0, 0, '2025-10-14 13:09:11', '2025-10-14 13:09:11'),
	(15, '4555', 16, 'Stewart Levine', 'Ina Hardy', 13, '9809465555', 'hajemomen@mailinator.com', '$2y$10$3hzol.fHULMX0asjyzdCpONcpi7OzG1.cOsAps1dV0Th9CPOrhjb6', 'user_20251014_185609_68ee4bede3be4.png', 0, 0, 0, '2025-10-14 13:11:10', '2025-10-14 13:11:10'),
	(16, '131323', 10, 'Suraj shahi', 'सुरज शाही', 27, '9809461774', 'superassdmin@gmail.com', '$2y$10$0PDJ3A1ZpN.5Xf4xJRv.VOX97rMJNP0RBpBnjVLHRi7plnT6mrbTG', 'user_20251014_191613_68ee50a16d744.png', 0, 0, 0, '2025-10-14 13:31:13', '2025-10-14 13:31:13');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
